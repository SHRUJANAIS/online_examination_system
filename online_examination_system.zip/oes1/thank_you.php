<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 20px;
        }
        h1 {
            color: #003366;
        }
        p {
            font-size: 18px;
        }
        .button {
            padding: 10px 20px;
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .button:hover {
            background-color: #0059b3;
        }
    </style>
</head>
<body>

<h1>Thank You for Participating!</h1>
<p>Your exam has been submitted successfully.</p>
<a href="index.php" class="button">Return to Home</a>

</body>
</html>
